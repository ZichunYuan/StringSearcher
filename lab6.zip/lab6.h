

char *search(char *strings[], int size, long range);

long evaluate( char *str, long range);

long count( char *str, long range);

